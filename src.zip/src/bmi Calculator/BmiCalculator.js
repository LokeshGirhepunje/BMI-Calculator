import { useState } from 'react'
import {Form,Container,Row,Col,Button} from 'react-bootstrap'
let msg = ''
const BmiCalculator = () =>
{
   
    let [weight, setweight] = useState(0)
    let [height, setheight] = useState(0)
    let [BmiREsult, setBmiREsult] = useState(0)
    

    const weightOfTheUser = (event) =>
    {
        setweight(weight=event.target.value)
    }

    const heightOfTheUser = (event) =>
    {
        setheight(height=event.target.value)
    }


    const ShowBmiResult =()=>
    {
      
        let BmiREsult=weight/((height/100)*(height/100))
        setBmiREsult(BmiREsult.toFixed(2))


        if (BmiREsult<18.5) {
            msg = "UnderWeight"
        } else if(BmiREsult>18.6 && BmiREsult<25){
            msg = "Normal"
        }
        
        else if(BmiREsult>25.1 && BmiREsult<30){
            msg = "OverWeight"
        }
        else if(BmiREsult>30){
            msg = "Obesity and please Go to Dr. for the treatment"
        }
    }

    return (
        <div className='mt-5'>
        <center><u><h1>Body Mass Index</h1></u></center>
        <Container className='w-25 mt-5' style={{border:'2px solid gray',height:'450px', borderRadius:'15px'}}>
            <Row className='mt-4'>
                <Col className="Col-md-4">
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                 <Form.Label>Weight (Kg)</Form.Label>
                    <Form.Control type="number" placeholder="Enter Your Weight  (Kg)" onChange={weightOfTheUser} style={{border:'2px solid black'}}/>
                </Form.Group>
                </Col>
            </Row>
            <Row>
                <Col className="Col-md-4">
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                   <Form.Label>Height (cm)</Form.Label>
                    <Form.Control type="number" placeholder="Enter Your height  (cm)" onChange={heightOfTheUser}style={{border:'2px solid black'}}/>
                </Form.Group>
                </Col>
            </Row>
            <br></br>
            <center><Row className='w-75'>
            
           
            <Button variant="success" onClick={ShowBmiResult}>Check BMI </Button>
           
           
            </Row></center>
<br></br>
<br></br>
            <Row>
               {
                BmiREsult>0 ?<center> <p style={{border:'1px solid gray' , width:'90%',borderRadius:'15px',padding:'15px'}}>Your Body Mass Index (BMI) is <b style={{color:'green'}}><u><h6 >{BmiREsult}</h6></u></b>. this is Consider as a <b><u><i>{msg}</i></u></b> </p></center>:''
               }

               
            </Row>

        </Container>
        </div>
    )
}
export default BmiCalculator;